# How Do
1. Unzip folder
2. Run "PCMaster.exe"
3. Connect your BMS via UART adapter cable
4. Click "commset" in the upper write hand corner and set the Port to the port the UART adapter is plugged into (this can be found in Device Manager)
# Tips, tricks, notes
- Sometimes It'll just crash when the BMS wakes up, or when a load is connected.
- I don't know what anything in "Engineering Tasks" does and I'm too afraid to try it
# Where the heck did this come from
This software was found on this DIY Solar Forum post: https://diysolarforum.com/resources/daly-smart-bms-pc-software.50/
